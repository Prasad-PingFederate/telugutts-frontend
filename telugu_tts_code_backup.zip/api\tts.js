// Vercel Serverless Function to proxy requests to RunPod
export default async function handler(req, res) {
    // Only allow POST requests
    if (req.method !== 'POST') {
        return res.status(405).json({ error: 'Method not allowed' });
    }

    try {
        const { text } = req.body;

        if (!text || !text.trim()) {
            return res.status(400).json({ error: 'No text provided' });
        }

        // RunPod Endpoint (Updated to user provided ID and runsync)
        const RUNPOD_ENDPOINT = 'https://api.runpod.ai/v2/76h1nrfetqvwu1/runsync';
        const RUNPOD_API_KEY = process.env.RUNPOD_API_KEY;

        console.log('Environment Check:', {
            hasKey: !!RUNPOD_API_KEY,
            keyStart: RUNPOD_API_KEY ? RUNPOD_API_KEY.substring(0, 4) : 'null'
        });

        if (!RUNPOD_API_KEY) {
            return res.status(500).json({
                error: 'Configuration Error',
                details: 'RUNPOD_API_KEY is missing. Please add it in Vercel Settings.'
            });
        }

        if (RUNPOD_API_KEY.startsWith('http')) {
            return res.status(500).json({
                error: 'Invalid API Key',
                details: 'You pasted the Endpoint URL into the RUNPOD_API_KEY variable. Please paste the actual Secret Key (starts with "rpa_").'
            });
        }

        console.log('Calling RunPod runsync endpoint...');

        // Call RunPod serverless endpoint
        const runpodResponse = await fetch(RUNPOD_ENDPOINT, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${RUNPOD_API_KEY}`
            },
            body: JSON.stringify({
                input: {
                    text: text
                }
            })
        });

        if (!runpodResponse.ok) {
            const errorText = await runpodResponse.text();
            console.error('RunPod error:', errorText);
            return res.status(500).json({
                error: 'RunPod API error',
                details: errorText
            });
        }

        const runpodData = await runpodResponse.json();
        console.log('RunPod response:', runpodData);

        // Handle runsync response
        if (runpodData.status === 'COMPLETED') {
            console.log('Job completed. Output type:', typeof runpodData.output);

            let audioData = runpodData.output;

            // Handle case where output is a JSON object containing the audio
            if (typeof audioData === 'object' && audioData !== null) {
                // Check for nested output first (based on user logs)
                if (audioData.output && audioData.output.audio_base64) {
                    audioData = audioData.output.audio_base64;
                }
                else if (audioData.output && audioData.output.audio) {
                    audioData = audioData.output.audio;
                }
                else if (audioData.audio) audioData = audioData.audio;
                else if (audioData.audio_base64) audioData = audioData.audio_base64;
                else if (audioData.b64) audioData = audioData.b64;
                else if (audioData.data) audioData = audioData.data;
            }

            // VALIDATION: If it is still an object or not a string, we failed.
            if (typeof audioData !== 'string') {
                console.error('Failed to extract string. Output:', runpodData.output);
                return res.status(500).json({
                    error: 'Invalid RunPod Output Format',
                    details: 'Expected audio string but got: ' + JSON.stringify(runpodData.output)
                });
            }

            return res.status(200).json({
                audio_base64: audioData,
                message: 'Audio generated successfully'
            });
        } else {
            // If status is not COMPLETED (e.g., IN_QUEUE, FAILED, TIMED_OUT)
            return res.status(500).json({
                error: 'Job failed or timed out',
                details: runpodData.error || `Status was ${runpodData.status}`
            });
        }

    } catch (error) {
        console.error('Error in API route:', error);
        return res.status(500).json({
            error: 'Internal server error',
            details: error.message
        });
    }
}