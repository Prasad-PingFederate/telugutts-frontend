// Get DOM elements
const teluguText = document.getElementById('teluguText');
const charCount = document.getElementById('charCount');
const generateBtn = document.getElementById('generateBtn');
const statusMessage = document.getElementById('statusMessage');
const audioPlayer = document.getElementById('audioPlayer');
const audio = document.getElementById('audio');
const downloadBtn = document.getElementById('downloadBtn');

let currentAudioBlob = null;

// Update character count
teluguText.addEventListener('input', () => {
    const count = teluguText.value.length;
    charCount.textContent = `${count} / 5000`;
});

// Show status message
function showStatus(message, type) {
    statusMessage.textContent = message;
    statusMessage.className = `status-message show ${type}`;
}

// Hide status message
function hideStatus() {
    statusMessage.className = 'status-message';
}

// Generate speech
generateBtn.addEventListener('click', async () => {
    const text = teluguText.value.trim();

    // Validation
    if (!text) {
        showStatus('⚠️ Please enter some Telugu text', 'error');
        return;
    }

    // Reset UI
    audioPlayer.style.display = 'none';
    hideStatus();

    // Show loading state
    generateBtn.classList.add('loading');
    generateBtn.disabled = true;
    showStatus('🔄 Generating speech... This may take a few seconds', 'loading');

    try {
        // Call the API
        const response = await fetch('/api/tts', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ text })
        });

        const data = await response.json();

        if (!response.ok) {
            const errorMessage = data.details
                ? `${data.error}: ${data.details}`
                : (data.error || 'Failed to generate speech');
            throw new Error(errorMessage);
        }

        // Check if we got audio data
        if (!data.audio_base64) {
            throw new Error('No audio data received');
        }

        // Convert base64 to blob
        // Create Blob from base64
        let base64String = data.audio_base64;

        // Fix: Clean the base64 string
        if (base64String.includes(',')) {
            base64String = base64String.split(',')[1];
        }
        base64String = base64String.replace(/\s/g, '');

        try {
            const audioData = atob(base64String);
            const audioArray = new Uint8Array(audioData.length);
            for (let i = 0; i < audioData.length; i++) {
                audioArray[i] = audioData.charCodeAt(i);
            }
            currentAudioBlob = new Blob([audioArray], { type: 'audio/mpeg' });
        } catch (e) {
            console.error('Base64 error:', e);
            throw new Error('Failed to decode audio data from server.');
        }


        // Create URL and play
        const audioUrl = URL.createObjectURL(currentAudioBlob);
        audio.src = audioUrl;

        // Show success
        showStatus('✅ ' + (data.message || 'Audio generated successfully!'), 'success');
        audioPlayer.style.display = 'block';

        // Auto-play the audio
        setTimeout(() => {
            audio.play().catch(err => {
                console.log('Auto-play prevented:', err);
            });
        }, 300);

    } catch (error) {
        console.error('Error:', error);
        showStatus(`❌ Error: ${error.message}`, 'error');
    } finally {
        // Reset button state
        generateBtn.classList.remove('loading');
        generateBtn.disabled = false;
    }
});

// Download audio
downloadBtn.addEventListener('click', () => {
    if (!currentAudioBlob) {
        showStatus('❌ No audio to download', 'error');
        return;
    }

    // Create download link
    const url = URL.createObjectURL(currentAudioBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `telugu-speech-${Date.now()}.mp3`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    showStatus('✅ Audio downloaded successfully!', 'success');
});

// Keyboard shortcut: Ctrl+Enter to generate
teluguText.addEventListener('keydown', (e) => {
    if (e.ctrlKey && e.key === 'Enter') {
        e.preventDefault();
        generateBtn.click();
    }
});
