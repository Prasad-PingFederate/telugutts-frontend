
from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import torch
import soundfile as sf
import base64
import io
import os
import logging
import numpy as np
from transformers import AutoModel, AutoTokenizer

# Configure Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("IndicF5-Server")

app = FastAPI(
    title="Ultimate Telugu TTS (IndicF5)",
    description="High-fidelity voice cloning description for Telugu",
    version="2.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global Variables for Model
model = None
tokenizer = None

@app.on_event("startup")
async def load_model():
    """
    Load the heavy IndicF5 model on startup.
    This runs once when the container starts.
    """
    global model, tokenizer
    try:
        logger.info("🚀 Loading IndicF5 Model (This takes time)...")
        # Ensure we are using GPU if available
        device = "cuda" if torch.cuda.is_available() else "cpu"
        logger.info(f"Running on device: {device}")

        # Load from Hugging Face (AI4Bharat)
        # Note: This requires the custom code trust
        model = AutoModel.from_pretrained("ai4bharat/IndicF5", trust_remote_code=True).to(device)
        tokenizer = AutoTokenizer.from_pretrained("ai4bharat/IndicF5", trust_remote_code=True)
        
        # Warmup
        logger.info("✅ Model Loaded Successfully!")
        
    except Exception as e:
        logger.error(f"❌ Failed to load model: {e}")
        raise RuntimeError("Model loading failed")

@app.get("/")
def health_check():
    return {"status": "online", "gpu": torch.cuda.is_available(), "model": "IndicF5"}

@app.post("/generate")
async def generate_speech(
    text: str = Form(...),
    reference_audio: UploadFile = File(None),
    reference_text: str = Form(None)
):
    """
    Generate Speech.
    If reference_audio is provided -> Voice Cloning.
    If not -> Uses default checkpoints (if available) or fails (IndicF5 usually needs a ref).
    """
    global model
    if not model:
        raise HTTPException(status_code=503, detail="Model is loading...")

    try:
        logger.info(f"📝 Receiving Text: {text[:50]}...")

        # 1. Process Reference Audio
        ref_audio_path = None
        if reference_audio:
            # Save upload to temp file
            temp_dir = "temp"
            os.makedirs(temp_dir, exist_ok=True)
            ref_audio_path = os.path.join(temp_dir, f"ref_{reference_audio.filename}")
            
            with open(ref_audio_path, "wb") as f:
                content = await reference_audio.read()
                f.write(content)
            
            logger.info(f"🎤 Using Voice Clone Reference: {reference_audio.filename}")
        else:
            # Use a default sample if none provided (You should upload a 'default_telugu.wav' to the container)
            ref_audio_path = "voices/default_telugu.wav"
            if not os.path.exists(ref_audio_path):
                 raise HTTPException(status_code=400, detail="No reference audio provided and default not found.")
            reference_text_final = "Default Reference Text" # Placeholder

        # 2. Inference
        # Note: Exact inference syntax depends on the specific IndicF5 wrapper
        # This is the standard transformers-like call based on their demo
        
        # The demo uses: model(text, ref_audio_path=..., ref_text=...)
        # We assume clean text here.
        
        if not reference_text:
             # In a real app, we might need to transcribe the audio or use a fixed text for the default voice
             pass

        logger.info("🔄 Generating Spectrogram...")
        
        with torch.no_grad():
             audio_out = model(
                text,
                ref_audio_path=ref_audio_path,
                ref_text=reference_text if reference_text else "Dummy reference text" 
             )

        # 3. Processing Output (Array to Base64)
        # Normalize
        if hasattr(audio_out, 'cpu'):
            audio_out = audio_out.cpu().numpy()
            
        if audio_out.dtype == np.int16:
            audio_out = audio_out.astype(np.float32) / 32768.0

        # Write to buffer
        buffer = io.BytesIO()
        sf.write(buffer, audio_out, 24000, format='MP3')
        buffer.seek(0)
        
        audio_base64 = base64.b64encode(buffer.read()).decode('utf-8')

        # Cleanup
        if reference_audio and os.path.exists(ref_audio_path):
             os.remove(ref_audio_path)

        return JSONResponse({
            "status": "success",
            "audio_base64": audio_base64
        })

    except Exception as e:
        logger.error(f"Generation Error: {e}")
        return JSONResponse(status_code=500, content={"error": str(e)})

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
