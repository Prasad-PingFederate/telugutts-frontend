
import runpod
import torch
import soundfile as sf
import base64
import io
import os
import numpy as np
from transformers import AutoModel
from huggingface_hub import login

# --- LOGIN ---
# We will use an environment variable for the token in Serverless
HF_TOKEN = os.environ.get("HF_TOKEN", "hf_qjRjEazjQjEazjQjEazjQjEazjQjEazjQj")
if HF_TOKEN:
    login(token=HF_TOKEN)

# Global model variable
model = None

def load_model():
    global model
    if model is None:
        device = "cuda" if torch.cuda.is_available() else "cpu"
        model = AutoModel.from_pretrained("ai4bharat/IndicF5", trust_remote_code=True).to(device)
    return model

def handler(job):
    """
    The handler function that will be called by RunPod Serverless.
    """
    global model
    
    # 1. Get input
    job_input = job["input"]
    text = job_input.get("text", "")
    
    if not text:
        return {"error": "No text provided"}

    # 2. Ensure model is loaded
    try:
        model = load_model()
    except Exception as e:
        return {"error": f"Model load failed: {str(e)}"}

    # 3. Generate
    try:
        # Dummy reference audio (Required by IndicF5)
        ref_audio_path = "voices/default_telugu.wav"
        if not os.path.exists(ref_audio_path):
            os.makedirs("voices", exist_ok=True)
            sr = 24000
            sf.write(ref_audio_path, np.zeros(sr, dtype=np.float32), sr)

        with torch.no_grad():
            audio_out = model(
                text,
                ref_audio_path=ref_audio_path,
                ref_text="ignored"
            )

        if hasattr(audio_out, 'cpu'):
            audio_out = audio_out.cpu().numpy()

        # 4. Encode to Base64
        buffer = io.BytesIO()
        sf.write(buffer, audio_out, 24000, format='MP3')
        buffer.seek(0)
        audio_base64 = base64.b64encode(buffer.read()).decode('utf-8')

        return {"audio_base64": audio_base64}

    except Exception as e:
        return {"error": f"Generation failed: {str(e)}"}

# Start the serverless worker
if __name__ == "__main__":
    runpod.serverless.start({"handler": handler})
