
import os
from huggingface_hub import login
from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import torch
import soundfile as sf
import base64
import io
import logging
import numpy as np
from transformers import AutoModel, AutoTokenizer

# --- AUTO LOGIN (FIXED) ---
# We hardcode your token here so you don't need 'huggingface-cli login'
# (In production, use env vars, but this gets you unstuck now)
try:
    login(token="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")
    print("✅ HuggingFace Login Successful inside Python!")
except Exception as e:
    print(f"⚠️ Login Warning: {e}")
# --------------------------

# Configure Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("IndicF5-Server")

app = FastAPI(
    title="Ultimate Telugu TTS (IndicF5)",
    description="High-fidelity voice cloning description for Telugu",
    version="2.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global Variables for Model
model = None

@app.on_event("startup")
async def load_model():
    """
    Load the heavy IndicF5 model on startup.
    This runs once when the container starts.
    """
    global model
    try:
        logger.info("🚀 Loading IndicF5 Model (This takes time)...")
        # Ensure we are using GPU if available
        device = "cuda" if torch.cuda.is_available() else "cpu"
        logger.info(f"Running on device: {device}")

        # Load from Hugging Face (AI4Bharat)
        # Note: This requires the custom code trust
        model = AutoModel.from_pretrained("ai4bharat/IndicF5", trust_remote_code=True).to(device)
        
        # Warmup
        logger.info("✅ Model Loaded Successfully!")
        
    except Exception as e:
        logger.error(f"❌ Failed to load model: {e}")
        # Dont raise error, just log it so server stays up for debugging
        print(f"CRITICAL ERROR: {e}")

@app.get("/")
def health_check():
    return {"status": "online", "gpu": torch.cuda.is_available(), "model": "IndicF5"}

@app.post("/generate")
async def generate_speech(
    text: str = Form(...),
    reference_audio: UploadFile = File(None)
):
    """
    Generate Speech.
    """
    global model
    if not model:
        raise HTTPException(status_code=503, detail="Model failed to load or is still loading.")

    try:
        logger.info(f"📝 Receiving Text: {text[:50]}...")
        
        # 1. Handle Reference Audio
        ref_audio_path = "voices/default_telugu.wav"
        
        if reference_audio:
            # We save it temporarily
            os.makedirs("temp", exist_ok=True)
            ref_audio_path = f"temp/{reference_audio.filename}"
            with open(ref_audio_path, "wb") as f:
                f.write(await reference_audio.read())

        # 2. Inference
        with torch.no_grad():
             # We use a dummy ref_text as IndicF5 sometimes needs it, but zero-shot works often without exact match
             audio_out = model(
                text,
                ref_audio_path=ref_audio_path,
                ref_text="ignored" 
             )

        # 3. Processing Output (Array to Base64)
        if hasattr(audio_out, 'cpu'):
            audio_out = audio_out.cpu().numpy()
            
        buffer = io.BytesIO()
        sf.write(buffer, audio_out, 24000, format='MP3')
        buffer.seek(0)
        
        audio_base64 = base64.b64encode(buffer.read()).decode('utf-8')

        return JSONResponse({
            "status": "success",
            "audio_base64": audio_base64
        })

    except Exception as e:
        logger.error(f"Generation Error: {e}")
        return JSONResponse(status_code=500, content={"error": str(e)})

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
